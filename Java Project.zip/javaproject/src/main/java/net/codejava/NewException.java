
package net.codejava;

import java.util.Scanner;

class javaproject {
  


    
    public static int getInfo(String stateInfo[][], String state) {
        int position = -1;
        boolean found = false;
        for (int index = 0; index < stateInfo.length && !found; index++) {
            if (stateInfo[index][0].equalsIgnoreCase(state))
                position = index;
        }
        return position;
    }



    public static void main(String[] args) {

            Scanner userInput = new Scanner(System.in);

            String[][] stateInformation = new String[][] {
                {
                    "AndhraPradesh", 
                    "Amaravathi",
                    "Jagan Mohan Reddy",
                    "Telugu",
                    "49.67 millions",
                    "7th largest state",
                    "Tirumala Tirupati,   Araku Valley ,"
                }, {
                    "Arunachalpradesh",
                    "Itanagar",
                    "Pema Khandu",
                    "English",
                    "1.255 millions",
                    "15th largest state",
                    "Tawang Monastery"
                }, {
                    "Assam",
                    "Dispur",
                    "Sarbananda Sonowal",
                    "Assamese",
                    "30.94 millions",
                    "17th largest state",
                    "Kaziranga National Park"
                }, {
                    "Bihar",
                    "Patna",
                    "Nitish Kumar",
                    "Hindi",
                    "99.02 millions",
                    "13th largest state",
                    " Kesariya,  Munger"
                }, {
                    "Chattisgarh",
                    "Raipur",
                    "Bhupesh Baghel",
                    "Hindi",
                    "25.55 millions",
                    "10th largest state",
                    "  Chitrakot Waterfalls, Sirpur, Rajim"
                }, {
                    "Goa",
                    "Panaji",
                    "Pramod Sawant",
                    "Konkani",
                    "1.817 millions",
                    "28th largest state",
                    " Dudhsagar Falls, Shantadurga, Anjuna Beach"
                }, {
                    "Gujarat",
                    "Gandhi Nagar",
                    "Vijay Rupani",
                    "Gujarati",
                    "62.7 millions",
                    "5th largest state",
                    " Sabarmati Ashram , Statue of Unity "
                }, {
                    "Haryana",
                    "Chandigarh",
                    "Manohar Lal Khat",
                    "Hindi",
                    "25.35 millions",
                    "21st largest state",
                    " Firoz Shah Palace Complex,  Asigarh Fort,  Blue Bird Lake"
                }, {
                    "Himachal Pradesh",
                    "Shimla",
                    "Jai Ram Thakur",
                    "Hindi",
                    "6.856 millions",
                    "16th largest state",
                    " Kullu,Manali, Shimla"
                }, {
                    "Jammu and Kashmir",
                    "Srinagar",
                    "Mehbooba Mufti",
                    "Urdu",
                    "12.55 millions",
                    "4th largest state",
                    "Ladakh,Dal Lake"
                }, {
                    "Jharkhand",
                    "Ranchi",
                    "Hemant Soren",
                    "oriya and urdu",
                    "31.9 milions",
                    "16th largest state",
                    " Dalma Wildlife Sanctuary,Dassam Falls"
                }, {
                    "Karnataka",
                    "Bengaluru",
                    "B. S. Yediyurappa",
                    "kannada",
                    "64.06 million",
                    "6th largest state",
                    "  Western Gangas,   Mysore Palace,Brahmagiri wildlife sanctuary, Jog Falls"
                }, {
                    "Kerala",
                    "Tiruvananthapuram",
                    "Pinarayi Vijayan",
                    "Malayalam",
                    "34.8 million",
                    "22nd largest state ",
                    "Malabar Coast, Nilgiri Biosphere Reserve"
                }, {
                    "Madhya Pradesh",
                    "Bhopal",
                    "Kamal Nath",
                    "Eastern Hindi",
                    "73.34 million",
                    "2nd largest state",
                    "Bandhavgarh National Park, Maheshwar, Maihar, Sanchi"
                }, {
                    "Maharashtra",
                    "Mumbai",
                    "Uddhav Thackeray",
                    "Marathi",
                    "114.2 million",
                    "3rd largest state",
                    " Ajanta Caves, Ellora Caves, Elephanta Caves, Nashik, Trimbak "
                }, {
                    "Manipur",
                    "Imphal",
                    "Nongthombam Biren",
                    "Manipuri",
                    "2.72 million",
                    "24th largest state",
                    " Churachandpur,Keibul Lamjao National Park,Loktak Lake"
                }, {
                    "Meghalaya ",
                    "Shillong",
                    "Conrad Sangma",
                    "English",
                    "3.211 million",
                    "23rd largest state",
                    "Cherrapunjee, Nohkalikai Falls"
                }, {
                    "Mizoram",
                    "Aizawl",
                    "Zoramthanga",
                    "Mizo",
                    "1.116 million",
                    "25th largest state",
                    "  Dampa Sanctuaries"
                }, {
                    "Nagaland",
                    "Kohima",
                    "Neiphiu Rio",
                    "creole",
                    "2.275 million",
                    "26th largest state",
                    " Hornbill Festival"
                }, {
                    "Odisha",
                    "Bhubaneswar",
                    "Naveen Patnaik",
                    "Oriya",
                    "43.77 million",
                    "9th largest state",
                    " Konark Sun Temple, Udayagiri and Khandagiri Caves"
                }, {
                    "Punjab",
                    "Chandigarh",
                    "Amarinder Singh",
                    "Indo-Aryan",
                    "27.98 million",
                    "20th largest state",
                    "Gobindgarh Fort,Durgiana Temple"
                }, {
                    "Rajasthan",
                    "Jaipur",
                    "Ashok Gehlot",
                    "Marwari",
                    "68.89 million",
                    "1st largest state",
                    "Jaipur, Thar Desert,Keoladeo National Park "
                }, {
                    "Sikkim",
                    "Gangtok",
                    "Prem Singh Tamang",
                    "Nepali",
                    "619,000",
                    "27th largest state",
                    "Mt. Kangchenjunga, Yuksom, Rabdentse"
                }, {
                    "Tamil Nadu",
                    "Chennai",
                    "K. Palanisamy ",
                    "Tamil",
                    "67.86 million",
                    "11th largest state",
                    " Marina beach, Thanjavur,  Thanjavur "
                }, {
                    "Telangana",
                    "Hyderabad",
                    "K. Chandrashekar Rao",
                    "35.19 million",
                    "12th largest state",
                    "Charminar ,Ramoji Film City,Warangal Fort"
                }, {
                    "Tripura",
                    "Agartala",
                    "Biplab Kumar Deb",
                    "Bengali",
                    "3.658 million",
                    "26th largest state",
                    "Ujjayanta Palace ,Pilak"
                }, {
                    "Uttarkhand",
                    "Dehradun",
                    "Trivendra Singh Rawat",
                    "Garhwali",
                    "10.08 million",
                    "18th largest state",
                    "Badrinath, Kedarnath, Gangotri ,Yamunotri "
                }, {
                    "Uttar Pradesh",
                    "Lucknow",
                    "Yogi Adityanath",
                    "Hindi",
                    "204.2 million",
                    "5th largest state",
                    "Taj Mahal,Varanasi,Ayodhya,Shantinath Temple"
                }, {
                    "West Bengal",
                    "Kolkata",
                    "Mamata Banerjee",
                    "Bengali",
                    "90.32 million",
                    "13th largest state",
                    "Victoria Memorial, Howrah Bridge,Sundarbans National Park"
                },

            };

            while (true) {
                
                 System.out.println("Enter a State or None to exit: ");
                String stateName = userInput.next();

                if (stateName.equalsIgnoreCase("None")) {
                    System.exit(0);
                } else {
                    int position = getInfo(stateInformation, stateName);
                    if (position != -1) {
                        System.out.println("Capital: " + stateInformation[position][1]);
                        System.out.println("Chief Minister: " + stateInformation[position][2]);
                        System.out.println("Language: " + stateInformation[position][3]);
                        System.out.println("Population: " + stateInformation[position][4]);
                        System.out.println("State Rank: " + stateInformation[position][5]);
                        System.out.println("Tourist Places : " + stateInformation[position][6]);
                    } else {
                        System.out.println("Invalid State Entered");
                    }
                }
            }
        }
    }        
        


    
    

